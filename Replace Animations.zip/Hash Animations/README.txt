This batch script allows you to quickly switch out Roblox animation cache files in your local Roblox temporary folder. It's useful for customizing in-game animation behavior such as Point, Wave, Cheer, Idle, or custom movement tweaks.

This script does not connect to the internet or download anything.

It only reads and writes local files under the Temp\Roblox\http directory.

It is open-source and can be inspected in any text editor.

Requires no admin rights and makes no system-wide changes.

Some antivirus programs flag .bat files automatically because:

They delete or modify files.

They run command-line operations.

They're distributed without a digital signature.

This is called a false positive. You can inspect the code yourself to ensure it’s safe.